#include <cs50.h>
#include <stdio.h>

// Two for and One if/else statement 
int main() {
    // for (int z = 0; z <= 12; z++) {
    //     for (int i = 0; i <= 12; i++) {
    //         if (i == 3 || i == 4 || i == 8 || i == 9 || z == 3 || z == 4 || z == 8 || z == 9) {
    //             printf("# ");
    //         } else {
    //             printf("  ");
    //         }
    //     }
    //     printf("\n");
    printf("Three divided by four is %.2lf", 1.0 * 3 / 4 );
    //WHY DOES THIS WORK NOW WHEN 1.0 IS MULTIPLIED BY 3 BUT NOT 4???
    // }
    // printf("\n");
}